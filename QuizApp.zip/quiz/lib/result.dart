import 'package:flutter/material.dart';

class Result extends StatelessWidget {
  final int resultScore;
  final Function()? resetHandler;
  Result(this.resultScore,this.resetHandler);

  String get resultPhrase {
    var resultText = 'So Bad !';
    if (resultScore <= 20) {
      resultText = 'You are awesome and Innocent';
    } else if (resultScore <= 32) {
      resultText = 'Pretty Likeable';
    } else if (resultScore <= 49) {
      resultText = 'You are Good!';
    } else if(resultScore >49 ){
      resultText = 'You are so Intelligent!';
    }
    return resultText;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Column(
          children: <Widget>[
            Container(
              width: ((MediaQuery.of(context).size.width) / 100) * 90,
              child: Center(
                child: Text(
                  "$resultPhrase",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text(
                  "Score: " + "$resultScore",
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
            ),
          ],
        ),
        Row(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: ElevatedButton(
                onPressed: resetHandler,
                child: Text('Restart Quiz'),
              ),
            )
          ],
        ),

      ],
    );
  }
}
