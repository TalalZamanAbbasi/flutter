import 'package:flutter/material.dart';

class Answer extends StatelessWidget {
  final Function selectHandler;
  final String answerText;
  Answer(this.selectHandler, this.answerText);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(.0),
      child: Container(
        width: ((MediaQuery.of(context).size.width) / 100) * 90,
        child: ElevatedButton(
          child: Text(answerText),
          onPressed: () {
            selectHandler();
          },
          style: ElevatedButton.styleFrom(
            primary: Colors.lightBlueAccent,
            shadowColor: Colors.pink,
          ),
        ),
      ),
    );
  }
}
