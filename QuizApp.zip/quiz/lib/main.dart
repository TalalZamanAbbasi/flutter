import 'package:flutter/material.dart';
import './result.dart';
import './quiz.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _MyAppState();
  }
}

class _MyAppState extends State<MyApp> {
  var _totalScore = 0;

  void _answerQuestion(int score) {
    _totalScore = _totalScore + score;
    setState(() {
      _questionIndex = _questionIndex + 1;
    });
    print(_questionIndex);
  }

  void _resetQuiz() {
    setState(() {
      _questionIndex = 0;
      _totalScore = 0;
    });
    print('Reset done');
  }

  var _questionIndex = 0;
  final _questions = const [
    {
      'questionText':
          'Which of the following countries has the largest area in the world?',
      'answers': [
        {'text': 'Canada', 'score': 0},
        {'text': 'China', 'score': 0},
        {'text': 'USA', 'score': 0},
        {'text': 'Russia', 'score': 10},
      ],
    },
    {
      'questionText': ' The longest canal in the world is:',
      'answers': [
        {'text': 'Nile', 'score': 0},
        {'text': 'Mississippi', 'score': 0},
        {'text': 'Amazon', 'score': 10},
        {'text': 'None of these', 'score': 0},
      ],
    },
    {
      'questionText': 'Which is the smallest country in the world?',
      'answers': [
        {'text': 'Naura', 'score': 0},
        {'text': 'Vatican City', 'score': 10},
        {'text': 'Monaco', 'score': 0},
        {'text': 'None of these', 'score': 0},
      ],
    },
    {
      'questionText': 'Which is the world’s largest mountain range?',
      'answers': [
        {'text': 'Alps', 'score': 0},
        {'text': 'Himalayas', 'score': 0},
        {'text': 'Andes', 'score': 10},
        {'text': 'None of these', 'score': 0},
      ],
    },
    {
      'questionText':
          'Which of the following countries leads in the production of tea?',
      'answers': [
        {'text': 'Pakistan', 'score': 0},
        {'text': 'India', 'score': 10},
        {'text': 'Myanmar', 'score': 0},
        {'text': 'None of these', 'score': 0},
      ],
    },
    {
      'questionText':
          ' Which metal is most abundantly found on the Earth’s surface?',
      'answers': [
        {'text': 'Aluminium', 'score': 0},
        {'text': 'Zinc', 'score': 0},
        {'text': 'Silicon', 'score': 10},
        {'text': 'None of these', 'score': 0},
      ],
    },
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.pink,
      ),
      home: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(100),
          child: AppBar(
            centerTitle: true,
            flexibleSpace: SafeArea(
              child: Center(
                child: Container(
                  width: 180,
                  height:90,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                    image: AssetImage(
                      'assets/logo.png',
                    ),
                    fit: BoxFit.fill,
                  )),
                ),
              ),
            ),
            // title: Text(
            //   'Quiz App',
            //   style: TextStyle(
            //       fontStyle: FontStyle.italic,
            //       fontWeight: FontWeight.bold,
            //       fontSize: 30),
            // ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(50),
                  bottomLeft: Radius.circular(50)),
            ),
          ),
        ),
        body: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(4,0,4,40),
                child: _questionIndex < _questions.length
                    ? Quiz(
                        questions: _questions,
                        answerQuestion: _answerQuestion,
                        questionIndex: _questionIndex,
                      )
                    : Result(_totalScore, _resetQuiz),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
